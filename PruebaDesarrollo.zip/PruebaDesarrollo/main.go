package main

import (
	"PruebaDesarrollo/binary"
	"PruebaDesarrollo/process"
	"bufio"
	"os"
	"fmt"
)

func main() {
	reader := bufio.NewReader(os.Stdin)
	fmt.Println("CADENA A TRADUCIR")
	fmt.Println("---------------------")
	cadenaTraducir, _ := reader.ReadString('\n')

	fmt.Println("FORMATO ORIGEN")
	fmt.Println("---------------------")
	origen, _ := reader.ReadString('\n')

	fmt.Println("FORMATO DESTINO")
	fmt.Println("---------------------")
	destino, _ := reader.ReadString('\n')

	binaryService:=binary.NewServiceBin()

	var processService  process.Repository
	processService=process.NewProcessService(binaryService)

	response:=processService.Traductor(cadenaTraducir,origen,destino)

	fmt.Println("TRADUCCION")
	fmt.Print(response)
}
