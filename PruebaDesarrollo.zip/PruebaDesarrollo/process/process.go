package process

import "PruebaDesarrollo/binary"

//Service ...
type Repository interface {
	Traductor(textoTraductir string, formatoOrigen string,formatoDestino string) string
}


type ProcessService struct {
	bin binary.Repository
}

func NewProcessService(bin binary.Repository)*ProcessService{
	return &ProcessService{bin}
}


func (s *ProcessService)Traductor(textoTraductir string, formatoOrigen string,formatoDestino string) string{

	if formatoDestino=="BIN\n" && formatoOrigen == "TEXT\n"{
		return s.bin.StringToBin(textoTraductir)

	}
	return ""
}

