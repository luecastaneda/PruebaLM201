package binary
import "fmt"


type Repository interface {
	StringToBin(cadena string) (binString string)
}

func NewServiceBin()*ServiceBin{
	return &ServiceBin{}
}

type ServiceBin struct{
}

func (bin *ServiceBin)StringToBin(cadena string) (binString string) {
	for _, c := range cadena {
		if c!=0{
			binString+=" "
		}
		binString = fmt.Sprintf("%s%b",binString, c)
	}
	return
}
